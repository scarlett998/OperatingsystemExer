
//description of a memory manager
//in this simple case we assume only one process
//otherwise the we need a list of Page Tables instead of only one
//It is also assumed that frame size is equal to page size

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.LinkedList;
import java.util.Queue;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.LinkedHashMap;

public class MemoryManager {

    private int NbrOfPages; //number of pages in virtual memory
    private int PageSize; //the number of bytes in one page
    private int NbrOfFrames; //number of frames in physical memory
    private int[] pageTable; //pageTable[n] gives the physical address for page n
    //-1 if page is not in physical memory
    private byte[] RAM; //physical memory RAM
    private RandomAccessFile pageFile;
    private int freePos; //points to the frame where we should insert page
    private int pageFaults=0;
    private  int[] frameTable;
    private int indexCounter;
    private int newIndex;
    private int[] valueArray;
    private Queue<Integer> pp=new LinkedList<>();
    LinkedHashMap<Integer,Integer> timeStamp;
    private boolean isFull=false;


    public MemoryManager(int pages,int pageSize,int frames,String pFile){
        try {
            //initiate the virtual memory
            NbrOfPages=pages;
            PageSize=pageSize;
            NbrOfFrames=frames;
            indexCounter=0;//
            freePos=0;
            //create pageTable
            //initially no pages loaded into physical memory
            pageTable=new int[NbrOfPages];
           // FIFO=new int[NbrOfPages];
            frameTable = new int[NbrOfFrames];
            for(int n=0;n<NbrOfPages;n++){
               pageTable[n]=-1;//pagetable change to feam
            }
            //allocate space for physical memory
            RAM=new byte[NbrOfFrames*PageSize];
            //
            valueArray = new int[frames];
            for (int i = 0; i < valueArray.length; i++) {
                valueArray[i] = 27;
            }
            //initiate page file
            pageFile=new RandomAccessFile(pFile,"r");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MemoryManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public byte read(int logicalAddress){
        //called by a process to read memory from its logical address
        byte data=0;
        //calculate pageNumber and index from the logical address
       // int pageNumber=(logicalAddress/NbrOfPages);
       // int index=logicalAddress%NbrOfPages;
       int pageNumber = (logicalAddress / PageSize);
       int index = logicalAddress - (pageNumber * PageSize);

       if(pp.contains(pageNumber)){
           pp.remove(pageNumber);
           pp.offer(pageNumber);
       }
        //check if we get a pageFault
        if(pageTable[pageNumber]==-1){
            //call method to solve page fault

            //pageFault(pageNumber);
            //the following two should be used in Task 2 and 3 of the seminar
            //pageFaultFIFO(pageNumber);
            pageFaultLRU(pageNumber);
        }
        //read data from RAM
        int frame=pageTable[pageNumber];
        int physicalAddress=frame*PageSize+index;
        data=RAM[physicalAddress];
        //print result
        System.out.print("Virtual address: "+logicalAddress);
        System.out.print(" Physical address: "+physicalAddress);
        System.out.println(" Value: "+data);
        return data;
    }

    //solve a page fault for page number pageNumber
    private void pageFault(int pageNumber){
        //this is the simple solution where we assume same size of physical and logical number
        pageFaults++;
        //load page into frame number freePos
        try {
            //read data from pageFile into RAM
            pageFile.seek(pageNumber*PageSize);
            for(int b=0;b<PageSize;b++)
                RAM[freePos*PageSize+b]=pageFile.readByte();
        } catch (IOException ex) {
            Logger.getLogger(MemoryManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        //update position to store next page
        pageTable[pageNumber]=freePos;
        freePos++;

    }
    private void pageFaultFIFO(int pageNumber){
        //this solution allows different size of physical and logical number
        //page replacement using FIFO
        //freePos is used to point to next position
        pageFaults++;
        int chekFrameTable = frameTable[freePos];

        if (chekFrameTable != -1){
            pageTable[chekFrameTable] = -1;
        }
        pageTable[pageNumber] = freePos;

        frameTable[freePos] = pageNumber;

        try {
            //read data from pageFile into RAM
            pageFile.seek(pageNumber*PageSize);
            for(int b=0;b<PageSize;b++) {
                //System.out.println(freePos);
                RAM[freePos * PageSize + b] = pageFile.readByte();
            }
        } catch (IOException ex) {
            Logger.getLogger(MemoryManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        freePos ++;
        if (freePos == NbrOfFrames){
            freePos = 0;
        }

    }

    //solve a page fault for page number pageNumber

    /*private void pageFaultFIFO(int pageNumber) {
        pageFaults++;

        if(isFull==true) {
            for (int i = 0; i < pageTable.length; i++) {
                if (pageTable[i] == freePos) {
                    pageTable[i] = -1;
                }
            }

        }
        //load page into frame number freePos
        try {
            //read data from pageFile into RAM
            pageFile.seek(pageNumber * PageSize);

            for (int b = 0; b < PageSize; b++) {
                RAM[freePos * PageSize + b] = pageFile.readByte();
            }
        } catch (IOException ex) {
            Logger.getLogger(MemoryManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        //FIFO[freePos] = pageNumber - 1;
        //update position to store neaxt page

        pageTable[pageNumber] = freePos;
        freePos++;
        if (freePos == NbrOfFrames) {
            isFull=true;
            freePos = 0;
        }
    }
*/
    /*private void pageFaultLRU(int pageNumber){
        //this solution allows different size of physical and logical number
        //victim is chosen by least recently used algorithm
        pageFaults++;
        int chekFrameTable = frameTable[freePos];
        System.out.println("freePos:"+freePos);

        if (chekFrameTable != -1){
           // updateFreePos();
            pp.add(freePos);
            chekFrameTable = frameTable[freePos];
            pageTable[chekFrameTable] = -1;
            //pageTable[freePos] = -1;
            //removeOldest();
            pp.remove(freePos);
        }
        pageTable[pageNumber] = freePos;

        frameTable[freePos] = pageNumber;

        timeStamp.put(pageNumber,pageTable[pageNumber]);

        try {
            //read data from pageFile into RAM
            pageFile.seek(pageNumber*PageSize);
            for(int b=0;b<PageSize;b++) {
                //System.out.println(freePos);
                RAM[freePos * PageSize + b] = pageFile.readByte();
            }
        } catch (IOException ex) {
            Logger.getLogger(MemoryManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        freePos ++;
        if (freePos >= NbrOfFrames){
            //System.out.println(NbrOfFrames);
            pp.add(freePos);
           // updateFreePos();

            isFull = true;
            //System.out.println("change: "+changeValue);
        }

    }

    //update position to store next page

*/

    //solve a page fault for page number pageNumber
    private void pageFaultLRU(int pageNumber) {
        //this solution allows different size of physical and logical number
        //victim is chosen by least recently used algorithm

       if(!pp.contains(pageNumber)&& isFull==true){
           int victimPage=pp.poll();
           freePos=pageTable[victimPage];
           pageTable[victimPage]=-1;
       }
        pageFaults++;



        try {
            //read data from pageFile into RAM
            pageFile.seek(pageNumber * PageSize);
            for (int b = 0; b < PageSize; b++) {
                RAM[newIndex * PageSize + b] = pageFile.readByte();
            }
        } catch (IOException ex) {
            Logger.getLogger(MemoryManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        //update position to store next page
        //FIFO[freePos] = pageNumber - 1;
pageTable[pageNumber]=freePos;
        if(isFull==false) freePos++;
        pp.offer(pageNumber);
        if(freePos==NbrOfFrames&&isFull==false){
            isFull=true;
            freePos=0;
        }
        freePos++;
        if(freePos==NbrOfFrames){
            freePos=0;
        }

    }

    public int getNbrOfPagefaults(){
        return pageFaults;
    }

}
