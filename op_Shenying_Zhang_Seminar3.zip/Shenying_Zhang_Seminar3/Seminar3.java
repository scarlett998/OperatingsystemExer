public class Seminar3 {

    public static void main(String[] args) {
        //create a Memory manager
        //256 pages
        //page size 256
        //256 frames in physical memory
        //page file located in BACKING_STORE.bin
        MemoryManager mmu=new MemoryManager(256,256,128,"BACKING_STORE.bin");
        //create a MemoryProcess
        //this object simulates memory access of a process
        //the virtual addresses to read from are specified in addresses.txt
        MemoryProcess mp=new MemoryProcess("addresses.txt",mmu);
        //simulate memory access
        mp.callMemory();
        //print number of page faults
        System.out.println("Page faults: "+mmu.getNbrOfPagefaults());
    }

}
